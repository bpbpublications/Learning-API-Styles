package com.pbp.ecomm.product.dto;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Map;

// dto/CreateProductRequest.java
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateProductRequest {

    @NotBlank(message = "Product name is required")
    @Size(min = 2, max = 255, message = "Name must be 2–255 characters")
    private String name;

    @Size(max = 5000, message = "Description must not exceed 5000 characters")
    private String description;

    @NotNull(message = "Price is required")
    @DecimalMin(value = "0.01", message = "Price must be greater than 0")
    @Digits(integer = 10, fraction = 2, message = "Invalid price format")
    private BigDecimal price;

    @NotBlank(message = "SKU is required")
    @Pattern(regexp = "^[A-Z0-9\\-]{3,50}$",
            message = "SKU must be 3–50 uppercase alphanumeric characters or hyphens")
    private String sku;

    @NotNull(message = "Category is required")
    private Integer categoryId;


    private String imageUrls;

    private Map<String, Object> attributes;

    @NotNull(message = "Initial stock quantity is required")
    @Min(value = 0, message = "Stock cannot be negative")
    private Integer initialStock;
}