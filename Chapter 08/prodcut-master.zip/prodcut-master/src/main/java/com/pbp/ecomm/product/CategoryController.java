package com.pbp.ecomm.product;

import com.pbp.ecomm.product.dto.CategoryDTO;
import com.pbp.ecomm.product.dto.CreateCategoryRequest;
import com.pbp.ecomm.product.dto.UpdateCategoryRequest;
import com.pbp.ecomm.product.services.CategoryService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for managing product categories.
 * <p>
 * Provides APIs for:
 * <ul>
 *     <li>Retrieving category hierarchy and details</li>
 *     <li>Searching categories</li>
 *     <li>Managing categories (Admin only)</li>
 * </ul>
 *
 * Base URL: /api/v1/categories
 */
@RestController
@RequestMapping("/api/v1/categories")
@RequiredArgsConstructor
public class CategoryController {

    private final CategoryService categoryService;

    // Public endpoints

    /**
     * Retrieves all active categories.
     * <p>
     * Returns only categories marked as active in the system.
     *
     * @return list of active categories
     */
    @GetMapping
    public ResponseEntity<List<CategoryDTO>> getAllActive() {
        return ResponseEntity.ok(categoryService.findAllActive());
    }


    /**
     * Retrieves all root-level categories.
     * <p>
     * Root categories are categories without a parent category.
     *
     * @return list of root categories
     */
    @GetMapping("/root")
    public ResponseEntity<List<CategoryDTO>> getRootCategories() {
        return ResponseEntity.ok(categoryService.findRootCategories());
    }

    /**
     * Retrieves category details by category ID.
     *
     * @param id unique category identifier
     * @return category details
     */
    @GetMapping("/{id}")
    public ResponseEntity<CategoryDTO> getById(@PathVariable Integer id) {
        return ResponseEntity.ok(categoryService.findById(id));
    }

    /**
     * Retrieves category details using category slug.
     * <p>
     * Slug is generally used for SEO-friendly URLs.
     *
     * @param slug category slug value
     * @return category details
     */
    @GetMapping("/slug/{slug}")
    public ResponseEntity<CategoryDTO> getBySlug(@PathVariable String slug) {
        return ResponseEntity.ok(categoryService.findBySlug(slug));
    }

    /**
     * Retrieves child categories for a given parent category.
     *
     * @param id parent category identifier
     * @return list of child categories
     */
    @GetMapping("/{id}/children")
    public ResponseEntity<List<CategoryDTO>> getChildren(@PathVariable Integer id) {
        return ResponseEntity.ok(categoryService.findChildren(id));
    }

    /**
     * Searches categories based on keyword or query text.
     *
     * @param q search keyword
     * @return matching category list
     */
    @GetMapping("/search")
    public ResponseEntity<List<CategoryDTO>> search(@RequestParam String q) {
        return ResponseEntity.ok(categoryService.search(q));
    }

    // Admin endpoints

    /**
     * Creates a new product category.
     * <p>
     * Accessible only to ADMIN users.
     *
     * @param req category creation request payload
     * @return created category details
     */
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<CategoryDTO> create(
            @Valid @RequestBody CreateCategoryRequest req) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(categoryService.create(req));
    }

    /**
     * Updates an existing category.
     * <p>
     * Accessible only to ADMIN users.
     *
     * @param id category identifier
     * @param req category update request payload
     * @return updated category details
     */
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<CategoryDTO> update(
            @PathVariable Integer id,
            @Valid @RequestBody UpdateCategoryRequest req) {

        return ResponseEntity.ok(categoryService.update(id, req));
    }

    /**
     * Deactivates a category from the system.
     * <p>
     * Accessible only to ADMIN users.
     * Category is soft-disabled instead of permanently deleted.
     *
     * @param id category identifier
     * @return HTTP 204 No Content response
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> deactivate(@PathVariable Integer id) {

        categoryService.deactivate(id);
        return ResponseEntity.noContent().build();
    }
}