package com.pbp.ecomm.product.filter;

import jakarta.validation.constraints.DecimalMin;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

// dto/ProductFilter.java
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductFilter {

    private Integer categoryId;
    private String keyword;         // searched across name + description

    @DecimalMin("0.00")
    private BigDecimal minPrice;

    @DecimalMin("0.00")
    private BigDecimal maxPrice;

    private Boolean inStockOnly;
    private Double minRating;       // e.g. 4.0 and above
    private String sortBy;          // price_asc | price_desc | rating | newest
}