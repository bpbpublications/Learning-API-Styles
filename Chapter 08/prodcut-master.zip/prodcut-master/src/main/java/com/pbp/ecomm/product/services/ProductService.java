package com.pbp.ecomm.product.services;

import com.pbp.ecomm.product.dto.CreateProductRequest;
import com.pbp.ecomm.product.dto.ProductDTO;
import com.pbp.ecomm.product.filter.ProductFilter;
import com.pbp.ecomm.product.model.Category;
import com.pbp.ecomm.product.model.Product;
import com.pbp.ecomm.product.mapper.ProductSpecification;
import com.pbp.ecomm.product.repo.CategoryRepository;
import com.pbp.ecomm.product.mapper.ProductMapper;
import com.pbp.ecomm.product.repo.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

// ProductService.java
@Service
@RequiredArgsConstructor
@Transactional
public class ProductService {

    private static final String CACHE_PREFIX = "product:";
    private final ProductRepository productRepo;
    @Autowired
    private final CategoryRepository categoryRepository;
    @Autowired
    private final ProductMapper productMapper;

    public ProductDTO findById(String id) throws Exception {
        String cacheKey = CACHE_PREFIX + id;
        Product product = productRepo.findById(id)
                .orElseThrow(() -> new Exception("Product not found: " + id));

        ProductDTO dto = productMapper.toDTO(product);
        return dto;
    }


    public Page<ProductDTO> findAll(ProductFilter filter, PageRequest pageable) {
        return productRepo.findAll(ProductSpecification.build(filter), pageable)
                .map(productMapper::toDTO);
    }

    public ProductDTO create(CreateProductRequest req) throws Exception {
        Optional<Category> category = categoryRepository.findById(req.getCategoryId());
        if (category.isEmpty()) {
            throw new Exception("category not found");
        }
        Product product = Product.create(req);

        product = productRepo.save(product);
        return productMapper.toDTO(product);
    }
}
