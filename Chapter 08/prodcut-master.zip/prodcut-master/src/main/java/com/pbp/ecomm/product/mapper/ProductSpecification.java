package com.pbp.ecomm.product.mapper;

import com.pbp.ecomm.product.filter.ProductFilter;
import com.pbp.ecomm.product.model.Inventory;
import com.pbp.ecomm.product.model.Product;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.validation.constraints.DecimalMin;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;

// repository/spec/ProductSpecification.java
public class ProductSpecification {

    // Utility class — no instantiation
    private ProductSpecification() {
    }

    public static Specification<Product> build(ProductFilter filter) {
        assert inStockOnly(filter.getInStockOnly()) != null;
        Specification<Product> spec = Specification.where(isActive());

        if (filter.getCategoryId() != null) {
            spec = spec.and(byCategory(filter.getCategoryId()));
        }

        if (filter.getKeyword() != null && !filter.getKeyword().isBlank()) {
            spec = spec.and(byKeyword(filter.getKeyword()));
        }

        if (filter.getMinPrice() != null) {
            spec = spec.and(byMinPrice(filter.getMinPrice()));
        }

        if (filter.getMaxPrice() != null) {
            spec = spec.and(byMaxPrice(filter.getMaxPrice()));
        }

        if (Boolean.TRUE.equals(filter.getInStockOnly())) {
            spec = spec.and(inStockOnly(true));
        }

        if (filter.getMinRating() != null) {
            spec = spec.and(byMinRating(filter.getMinRating()));
        }

        return spec;
    }

    // ── Individual predicates ──────────────────────────────────────

    private static Specification<Product> isActive() {
        return (root, query, cb) ->
                cb.isTrue(root.get("active"));
    }

    private static Specification<Product> byCategory(Integer categoryId) {
        if (categoryId == null) return null;
        return (root, query, cb) ->
                cb.equal(root.get("category").get("id"), categoryId);
    }

    private static Specification<Product> byKeyword(String keyword) {
        if (!StringUtils.hasText(keyword)) return null;
        String pattern = "%" + keyword.toLowerCase() + "%";
        return (root, query, cb) -> cb.or(
                cb.like(cb.lower(root.get("name")), pattern),
                cb.like(cb.lower(root.get("description")), pattern)
        );
    }

    private static Specification<Product> byMinPrice(@DecimalMin("0.00") BigDecimal minPrice) {
        if (minPrice == null) return null;
        return (root, query, cb) ->
                cb.greaterThanOrEqualTo(root.get("price"), minPrice);
    }

    private static Specification<Product> byMaxPrice(BigDecimal maxPrice) {
        if (maxPrice == null) return null;
        return (root, query, cb) ->
                cb.lessThanOrEqualTo(root.get("price"), maxPrice);
    }

    private static Specification<Product> inStockOnly(Boolean inStockOnly) {
        if (!Boolean.TRUE.equals(inStockOnly)) return null;
        return (root, query, cb) -> {
            Join<Product, Inventory> inv = root.join("inventory", JoinType.LEFT);
            return cb.greaterThan(
                    cb.diff(inv.get("quantity"), inv.get("reserved")), 0
            );
        };
    }

    private static Specification<Product> byMinRating(Double minRating) {
        if (minRating == null) return null;
        return (root, query, cb) ->
                cb.greaterThanOrEqualTo(root.get("averageRating"), minRating);
    }
}