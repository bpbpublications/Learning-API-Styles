package com.pbp.ecomm.product.mapper;

import com.pbp.ecomm.product.dto.CategoryDTO;
import com.pbp.ecomm.product.model.Category;
import org.mapstruct.IterableMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.List;

@Mapper(componentModel = "spring")
public interface CategoryMapper {

    // ========================
    // ENTITY → DTO (FLAT)
    // ========================
    @Mapping(target = "parentId", source = "parent.id")
    @Mapping(target = "parentName", source = "parent.name")
    @Mapping(target = "children", ignore = true)
    // avoid recursion by default
    CategoryDTO toDto(Category category);

    List<CategoryDTO> toDtoList(List<Category> categories);

    // ========================
    // ENTITY → DTO (TREE)
    // ========================
    @Named("toDtoTree")
    @Mapping(target = "parentId", source = "parent.id")
    @Mapping(target = "parentName", source = "parent.name")
    @Mapping(target = "children", source = "children", qualifiedByName = "toDtoTree")
    CategoryDTO toDtoTree(Category category);

    @IterableMapping(qualifiedByName = "toDtoTree")
    List<CategoryDTO> toDtoTreeList(List<Category> categories);

    // ========================
    // DTO → ENTITY
    // ========================
    @Mapping(target = "parent", ignore = true) // set manually in service
    @Mapping(target = "children", ignore = true)
    Category toEntity(CategoryDTO dto);

    List toDTOWithChildren(Category category);
}