package com.pbp.ecomm.product.mapper;

import com.pbp.ecomm.product.dto.CreateProductRequest;
import com.pbp.ecomm.product.dto.ProductDTO;
import com.pbp.ecomm.product.model.Category;
import com.pbp.ecomm.product.model.Product;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

import java.math.BigDecimal;
import java.math.RoundingMode;

// mapper/ProductMapper.java
@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ProductMapper {

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    @Mapping(target = "inventory", ignore = true)
    @Mapping(target = "reviews", ignore = true)
    @Mapping(target = "averageRating", constant = "0.0")
    @Mapping(target = "reviewCount", constant = "0")
    @Mapping(target = "active", constant = "true")

    // price scale enforced in @AfterMapping
    @Mapping(target = "price", source = "price")

    // category set from ID in @AfterMapping
    @Mapping(target = "category", ignore = true)

    // sku normalised in @AfterMapping
    @Mapping(target = "sku", source = "sku")

    public static Product toEntity(CreateProductRequest req) {
        return null;
    }

    @Mapping(target = "category",
            expression = "java(toCategorySummary(product.getCategory()))")

    @Mapping(target = "stockQuantity",
            expression = "java(resolveStockQuantity(product))")

    @Mapping(target = "inStock",
            expression = "java(product.isInStock())")

    @Mapping(target = "price",
            source = "price")

    @Mapping(target = "discountedPrice",
            expression = "java(product.getEffectivePrice().equals(product.getPrice()) "
                    + "? null : product.getEffectivePrice())")

    @Mapping(target = "discountPercent",
            source = "discountPercent")

    @Mapping(target = "imageUrls",
            source = "imageUrls")

    @Mapping(target = "attributes",
            source = "attributes")

    @Mapping(target = "averageRating",
            source = "averageRating")

    @Mapping(target = "reviewCount",
            source = "reviewCount")

    @Mapping(target = "active",
            source = "active")

    @Mapping(target = "createdAt",
            source = "createdAt")

    @Mapping(target = "updatedAt",
            source = "updatedAt")
    ProductDTO toDTO(Product product);


    ProductDTO.CategorySummary toCategorySummary(Category category);

    default BigDecimal calculateDiscountedPrice(Product p) {
        if (p.getDiscountPercent() == null || p.getDiscountPercent().doubleValue() == 0) return null;
        BigDecimal factor = BigDecimal.ONE
                .subtract(BigDecimal.valueOf(p.getDiscountPercent().doubleValue() / 100));
        return p.getPrice().multiply(factor)
                .setScale(2, RoundingMode.HALF_UP);
    }

    default Integer resolveStockQuantity(Product product) {
        if (product.getInventory() == null) return 0;
        return product.getInventory().getAvailableQuantity();
    }

    default Double calculateDiscountPercent(Product p) {
        return p.getDiscountPercent().doubleValue();
    }
}
