package com.pbp.ecomm.product.excption;

public class InsufficientStockException extends Exception {
    public InsufficientStockException(String s) {
        super(s);
    }
}
