package com.pbp.ecomm.product.model;

import com.pbp.ecomm.product.excption.InsufficientStockException;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

// model/Inventory.java
@Entity
@Table(name = "inventory")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Inventory {

    @Id
    @Column(name = "product_id")
    private String productId;

    @OneToOne(fetch = FetchType.LAZY)
    @MapsId                         // shares PK with Product
    @JoinColumn(name = "product_id",
            foreignKey = @ForeignKey(name = "fk_inventory_product"))
    private Product product;

    @Column(nullable = false)
    @Builder.Default
    private Integer quantity = 0;   // total physical stock

    @Column(nullable = false)
    @Builder.Default
    private Integer reserved = 0;   // locked by pending orders

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    // ── Business logic ────────────────────────────────────────────

    /**
     * Available = total stock minus what's already reserved by pending orders.
     */
    public int getAvailableQuantity() {
        return Math.max(0, quantity - reserved);
    }

    /**
     * Reserves stock at order creation time.
     * Throws if insufficient available quantity.
     */
    public void reserve(int qty) throws InsufficientStockException {
        if (getAvailableQuantity() < qty) {
            throw new InsufficientStockException(
                    "Only " + getAvailableQuantity() + " units available"
            );
        }
        this.reserved += qty;
    }

    /**
     * Releases reservation — called on order cancellation.
     */
    public void release(int qty) {
        this.reserved = Math.max(0, reserved - qty);
    }

    /**
     * Confirms fulfillment — deducts from both total and reserved.
     * Called when order is shipped.
     */
    public void fulfil(int qty) {
        this.reserved = Math.max(0, reserved - qty);
        this.quantity = Math.max(0, quantity - qty);
    }
}