package com.pbp.ecomm.product;

import com.pbp.ecomm.product.dto.CreateProductRequest;
import com.pbp.ecomm.product.dto.ProductDTO;
import com.pbp.ecomm.product.filter.ProductFilter;
import com.pbp.ecomm.product.filter.AuthenticatedUser;
import com.pbp.ecomm.product.services.ProductService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

/**
 * REST controller for managing product-related operations.
 * <p>
 * Provides APIs for:
 * <ul>
 *     <li>Fetching product list with filtering and pagination</li>
 *     <li>Fetching product details by ID</li>
 *     <li>Creating new products (Admin only)</li>
 * </ul>
 *
 * Base URL: /api/v1/products
 */
@RestController
@RequestMapping("/api/v1/products")
@RequiredArgsConstructor
@Slf4j
public class ProductController {

    private final ProductService productService;

    /**
     * Retrieves paginated list of products based on provided filters.
     * <p>
     * This endpoint is publicly accessible and supports filtering,
     * searching, and pagination.
     *
     * @param filter filter criteria such as category, price, brand, etc.
     * @param pageable pagination configuration
     * @return paginated list of products
     */
    @GetMapping
    public ResponseEntity<Page<ProductDTO>> getProducts(
            @ModelAttribute ProductFilter filter,
            @PageableDefault(size = 20) Pageable pageable) {

        return ResponseEntity.ok(
                productService.findAll(filter, (PageRequest) pageable)
        );
    }

    /**
     * Retrieves detailed information about a specific product.
     * <p>
     * This endpoint is publicly accessible.
     *
     * @param id unique identifier of the product
     * @return product details
     * @throws Exception if product is not found
     */
    @GetMapping("/{id}")
    public ResponseEntity<ProductDTO> getProduct(
            @PathVariable String id) throws Exception {

        return ResponseEntity.ok(productService.findById(id));
    }

    /**
     * Creates a new product in the system.
     * <p>
     * Accessible only to users with ADMIN role.
     * Uses method-level security as an additional authorization layer.
     *
     * @param req request payload containing product details
     * @param admin authenticated admin user performing the operation
     * @return created product details
     * @throws Exception if product creation fails
     */
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ProductDTO> create(
            @Valid @RequestBody CreateProductRequest req,
            @AuthenticationPrincipal AuthenticatedUser admin) throws Exception {

        log.info("Product creation by admin={}", admin.getUserId());

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(productService.create(req));
    }
}