package com.pbp.ecomm.product.model;


import com.pbp.ecomm.product.dto.CreateProductRequest;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Entity
@Table(
        name = "products",
        indexes = {
                @Index(name = "idx_product_sku", columnList = "sku", unique = true),
                @Index(name = "idx_product_category", columnList = "category_id"),
                @Index(name = "idx_product_active", columnList = "is_active"),
                @Index(name = "idx_product_price", columnList = "price"),
                @Index(name = "idx_product_rating", columnList = "average_rating"),
                @Index(name = "idx_product_created", columnList = "created_at")
        }
)
@EntityListeners(AuditingEntityListener.class)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)   // avoid Hibernate proxy issues
@ToString(exclude = {"reviews", "inventory"})        // prevent lazy-load in logs
public class Product {

    // ── Identity ──────────────────────────────────────────────────

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @EqualsAndHashCode.Include
    @Column(updatable = false, nullable = false)
    private String id;

    // ── Core Fields ───────────────────────────────────────────────

    @Column(nullable = false, length = 255)
    private String name;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(nullable = false, unique = true, length = 100)
    private String sku;                 // Stock Keeping Unit — e.g. "SHOE-NK-RED-42"

    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal price;

    @Column(name = "discount_percent")
    private BigDecimal discountPercent;     // e.g. 15.0 means 15% off; null = no discount

    // ── Relationships ─────────────────────────────────────────────

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "category_id", nullable = false,
            foreignKey = @ForeignKey(name = "fk_product_category"))
    private Category category;

    @OneToOne(
            mappedBy = "product",
            cascade = CascadeType.ALL,
            fetch = FetchType.LAZY,
            orphanRemoval = true
    )
    private Inventory inventory;

    @OneToMany(
            mappedBy = "product",
            cascade = CascadeType.ALL,
            fetch = FetchType.LAZY,
            orphanRemoval = true
    )
    @OrderBy("createdAt DESC")
    private List<Review> reviews = new ArrayList<>();

    // ── Media ─────────────────────────────────────────────────────

    /*  @ElementCollection
      @CollectionTable(
              name = "product_images",
              joinColumns = @JoinColumn(name = "product_id"),
              foreignKey = @ForeignKey(name = "fk_product_images_product")
      )*/
    @Column(name = "image_urls", nullable = false, length = 1000)
    /*@OrderColumn(name = "display_order")    // preserves insertion order
    @Builder.Default*/
    private String imageUrls;

    // ── Flexible Attributes (JSONB) ───────────────────────────────
    // Stores dynamic product specs: color, size, brand, weight, material, etc.
    // Avoids EAV anti-pattern while remaining schema-flexible

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(columnDefinition = "jsonb")
    private Map<String, Object> attributes = new HashMap<>();

    // ── Ratings Denormalised ──────────────────────────────────────
    // Maintained by ReviewService via updateRatingStats() — avoids
    // expensive AVG() aggregation on every product fetch

    @Column(name = "average_rating", precision = 3, scale = 2)
    @Builder.Default
    private BigDecimal averageRating = BigDecimal.valueOf(0.0);

    @Column(name = "review_count")
    @Builder.Default
    private Integer reviewCount = 0;

    // ── Status ────────────────────────────────────────────────────

    @Column(name = "is_active", nullable = false)
    @Builder.Default
    private Boolean active = true;

    // ── Auditing ──────────────────────────────────────────────────

    @CreatedDate
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @LastModifiedDate
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    // ── Business Logic Methods ────────────────────────────────────
    // Keeping domain behaviour on the entity (DDD-lite approach)

    /**
     * Named constructor — creates a new, unpersisted Product
     * from a validated CreateProductRequest.
     * <p>
     * Follows the DDD principle of keeping creation logic
     * on the aggregate root itself.
     */
    public static Product create(CreateProductRequest req) {
        Objects.requireNonNull(req, "CreateProductRequest must not be null");

        // Normalise SKU before building
        String normalizedSku = req.getSku().trim().toUpperCase();

        // Enforce price scale
        BigDecimal normalizedPrice = req.getPrice()
                .setScale(2, RoundingMode.HALF_UP);

        // Category proxy — FK only, no SELECT
        Category categoryRef = new Category();
        categoryRef.setId(req.getCategoryId());

        // Clean image list
        String images = req.getImageUrls();

        // Clean attributes map
        Map<String, Object> attrs = Optional.ofNullable(req.getAttributes())
                .orElse(Collections.emptyMap())
                .entrySet().stream()
                .filter(e -> e.getKey() != null && e.getValue() != null)
                .collect(Collectors.toMap(
                        e -> e.getKey().trim().toLowerCase(),
                        Map.Entry::getValue,
                        (a, b) -> a,
                        HashMap::new
                ));

        return Product.builder()
                .name(req.getName().trim().replaceAll("\\s+", " "))
                .description(req.getDescription() != null
                        ? req.getDescription().trim() : null)
                .sku(normalizedSku)
                .price(normalizedPrice)
                //.discountPercent(req.getDiscountPercen)
                .category(categoryRef)
                .imageUrls(images)
                .attributes(attrs)
                .averageRating(BigDecimal.valueOf(0.0))
                .reviewCount(0)
                .active(true)
                .reviews(new ArrayList<>())
                .build();
    }

    /**
     * Returns effective selling price after applying any discount.
     * Used by order service during checkout to lock in price at time of purchase.
     */
    public BigDecimal getEffectivePrice() {
        if (discountPercent == null || discountPercent.doubleValue() <= 0) {
            return price;
        }
        BigDecimal multiplier = BigDecimal.ONE
                .subtract(BigDecimal.valueOf(discountPercent.doubleValue() / 100));
        return price.multiply(multiplier)
                .setScale(2, java.math.RoundingMode.HALF_UP);
    }

    /**
     * True if the product has inventory assigned and available stock > 0.
     */
    public boolean isInStock() {
        return inventory != null && inventory.getAvailableQuantity() > 0;
    }

    /**
     * Convenience method — returns the primary (first) image URL.
     * Falls back to null if no images uploaded.
     */
    public String getPrimaryImageUrl() {
        return imageUrls;
    }

    /**
     * Adds a review and recalculates denormalised rating stats in-place.
     * Call productRepository.save() after this to persist.
     */
    public void addReview(Review review) {
        reviews.add(review);
        review.setProduct(this);
        recalculateRating();
    }

    /**
     * Recomputes averageRating and reviewCount from the current reviews list.
     * Intentionally kept as a pure in-memory calculation — no DB call.
     */
    public void recalculateRating() {
        if (reviews.isEmpty()) {
            this.averageRating = BigDecimal.valueOf(0.0);
            this.reviewCount = 0;
            return;
        }
        this.reviewCount = reviews.size();
        this.averageRating = BigDecimal.valueOf(reviews.stream()
                .mapToInt(Review::getRating)
                .average()
                .orElse(0.0));
        // Round to 2 decimal places
        this.averageRating = BigDecimal.valueOf(Math.round(averageRating.doubleValue() * 100.0) / 100.0);
    }

    /**
     * Deactivates the product — soft delete.
     * Inventory reservations are NOT affected; existing orders are honoured.
     */
    public void deactivate() {
        this.active = false;
    }
    // Inside Product.java

    /**
     * Updates mutable fields from an update request.
     * Null fields are treated as "no change" — partial update semantics.
     */
    public void applyUpdate(String name, String description,
                            BigDecimal price, BigDecimal discountPercent,
                            String imageUrls, Map<String, Object> attributes,
                            Boolean active) {

        if (name != null) this.name = name;
        if (description != null) this.description = description;
        if (price != null) this.price = price;
        if (discountPercent != null) this.discountPercent = discountPercent;
        if (imageUrls != null) this.imageUrls = imageUrls;
        if (attributes != null) this.attributes = attributes;
        if (active != null) this.active = active;
    }


}