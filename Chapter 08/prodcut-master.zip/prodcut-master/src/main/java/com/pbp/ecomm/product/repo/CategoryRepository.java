package com.pbp.ecomm.product.repo;


import com.pbp.ecomm.product.model.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CategoryRepository extends JpaRepository<Category, Integer> {

    // ── Basic lookups ─────────────────────────────────────────────

    Optional<Category> findBySlug(String slug);

    Optional<Category> findByName(String name);

    boolean existsBySlug(String slug);

    boolean existsByName(String name);

    // Exclude current category when checking duplicate on update
    boolean existsBySlugAndIdNot(String slug, Integer id);

    boolean existsByNameAndIdNot(String name, Integer id);

    // ── Active categories ─────────────────────────────────────────

    List<Category> findAllByActiveTrueOrderByNameAsc();

    Optional<Category> findByIdAndActiveTrue(Integer id);

    Optional<Category> findBySlugAndActiveTrue(String slug);

    // ── Parent / Child hierarchy ──────────────────────────────────

    // Top-level categories (no parent)
    List<Category> findByParentIsNullAndActiveTrueOrderByNameAsc();

    // Direct children of a given parent
    List<Category> findByParentIdAndActiveTrueOrderByNameAsc(Integer parentId);

    // Check if a category has children before deleting
    boolean existsByParentId(Integer parentId);

    // ── Full tree — single query with JOIN FETCH ──────────────────

    @Query("""
                SELECT c FROM Category c
                LEFT JOIN FETCH c.children ch
                WHERE c.parent IS NULL
                  AND c.active = true
                ORDER BY c.name ASC
            """)
    List<Category> findFullTreeActive();

    // ── Category with products count ──────────────────────────────

    @Query("""
                SELECT c FROM Category c
                LEFT JOIN FETCH c.children
                WHERE c.id = :id
            """)
    Optional<Category> findByIdWithChildren(@Param("id") Integer id);

    // ── Bulk operations ───────────────────────────────────────────

    @Modifying
    @Query("UPDATE Category c SET c.active = false WHERE c.id = :id")
    int deactivateById(@Param("id") Integer id);

    @Modifying
    @Query("UPDATE Category c SET c.active = false WHERE c.parent.id = :parentId")
    int deactivateAllChildrenOf(@Param("parentId") Integer parentId);

    @Modifying
    @Query("UPDATE Category c SET c.active = true WHERE c.id = :id")
    int activateById(@Param("id") Integer id);

    // ── Search ────────────────────────────────────────────────────

    @Query("""
                SELECT c FROM Category c
                WHERE c.active = true
                  AND LOWER(c.name) LIKE LOWER(CONCAT('%', :keyword, '%'))
                ORDER BY c.name ASC
            """)
    List<Category> searchByName(@Param("keyword") String keyword);

    // ── Validation support ────────────────────────────────────────

    // Used by ProductService to validate categoryId before product creation
    @Query("SELECT COUNT(c) > 0 FROM Category c WHERE c.id = :id AND c.active = true")
    boolean isActiveCategory(@Param("id") Integer id);
}