package com.pbp.ecomm.product.repo;

import com.pbp.ecomm.product.model.Product;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

// repository/ProductRepository.java
@Repository
public interface ProductRepository
        extends JpaRepository<Product, String>,
        JpaSpecificationExecutor<Product> {

    // ── Simple lookups ────────────────────────────────────────────

    Optional<Product> findByIdAndActiveTrue(String id);

    Optional<Product> findBySku(String sku);

    boolean existsBySku(String sku);

    boolean existsBySkuAndIdNot(String sku, String id);   // for update validation

    // ── Category queries ──────────────────────────────────────────

    Page<Product> findByCategoryIdAndActiveTrue(
            Integer categoryId, Pageable pageable);

    long countByCategoryIdAndActiveTrue(Integer categoryId);

    // ── Admin queries ─────────────────────────────────────────────

    Page<Product> findAllByActiveTrue(Pageable pageable);

    Page<Product> findAllByActiveFalse(Pageable pageable);  // deactivated products

    // ── Price range ───────────────────────────────────────────────

    @Query("""
                SELECT p FROM Product p
                WHERE p.active = true
                  AND p.price BETWEEN :minPrice AND :maxPrice
                ORDER BY p.price ASC
            """)
    Page<Product> findByPriceRange(
            @Param("minPrice") BigDecimal minPrice,
            @Param("maxPrice") BigDecimal maxPrice,
            Pageable pageable);

    // ── Featured / top-rated ──────────────────────────────────────

    @Query("""
                SELECT p FROM Product p
                WHERE p.active = true
                  AND p.averageRating >= :minRating
                ORDER BY p.averageRating DESC, p.reviewCount DESC
            """)
    List<Product> findTopRated(
            @Param("minRating") Double minRating,
            Pageable pageable);

    // ── New arrivals ──────────────────────────────────────────────

    @Query("""
                SELECT p FROM Product p
                WHERE p.active = true
                ORDER BY p.createdAt DESC
            """)
    List<Product> findNewArrivals(Pageable pageable);

    // ── Low stock alert (for inventory team) ──────────────────────

    @Query("""
                SELECT p FROM Product p
                JOIN p.inventory i
                WHERE p.active = true
                  AND (i.quantity - i.reserved) <= :threshold
                ORDER BY (i.quantity - i.reserved) ASC
            """)
    List<Product> findLowStockProducts(@Param("threshold") int threshold);

    // ── Bulk operations ───────────────────────────────────────────

    @Modifying
    @Query("UPDATE Product p SET p.active = false WHERE p.id IN :ids")
    int deactivateByIds(@Param("ids") List<String> ids);

    @Modifying
    @Query("""
                UPDATE Product p
                SET p.averageRating = :rating, p.reviewCount = :count
                WHERE p.id = :productId
            """)
    void updateRatingStats(
            @Param("productId") String productId,
            @Param("rating") Double rating,
            @Param("count") Integer count);

    // ── Elasticsearch sync support ────────────────────────────────

    @Query("""
                SELECT p FROM Product p
                LEFT JOIN FETCH p.category
                LEFT JOIN FETCH p.inventory
                WHERE p.active = true
                  AND p.updatedAt > :since
            """)
    List<Product> findUpdatedSince(@Param("since") LocalDateTime since);

    // ── Count by category (for category listing page) ─────────────

    @Query("""
                SELECT c.id AS categoryId,
                       c.name AS categoryName,
                       COUNT(p) AS productCount
                FROM Product p
                JOIN p.category c
                WHERE p.active = true
                GROUP BY c.id, c.name
            """)
    List<CategoryProductCount> countActiveProductsByCategory();

    // Projection interface for above query
    interface CategoryProductCount {
        Integer getCategoryId();

        String getCategoryName();

        Long getProductCount();
    }
}