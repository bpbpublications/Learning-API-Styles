package com.pbp.ecomm.product.services;

import com.pbp.ecomm.product.dto.*;
import com.pbp.ecomm.product.model.Category;
import com.pbp.ecomm.product.mapper.CategoryMapper;
import com.pbp.ecomm.product.repo.CategoryRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service @RequiredArgsConstructor @Transactional @Slf4j
public class CategoryService {

    private final CategoryRepository categoryRepo;
    private final CategoryMapper categoryMapper;

    @CacheEvict(value = "categories", allEntries = true)
    public CategoryDTO create(CreateCategoryRequest req) {
        String name = req.getName(), slug = generateSlug(name);
        if (categoryRepo.existsByName(name))
            throw new RuntimeException("Category with name '" + name + "' already exists");
        if (categoryRepo.existsBySlug(slug))
            throw new RuntimeException("Category with slug '" + slug + "' already exists");

        Category category = Category.builder()
                .name(name.trim()).slug(slug).imageUrl(req.getImageUrl()).active(true).build();

        if (req.getParentId() != null)
            category.setParent(categoryRepo.findByIdAndActiveTrue(req.getParentId())
                    .orElseThrow(() -> new RuntimeException("Parent category not found: " + req.getParentId())));

        Category saved = categoryRepo.save(category);
        log.info("Category created id={} name={}", saved.getId(), saved.getName());
        return categoryMapper.toDto(saved);
    }

    @Transactional(readOnly = true)
    @Cacheable(value = "categories", key = "#id")
    public CategoryDTO findById(Integer id) {
        return categoryRepo.findByIdAndActiveTrue(id).map(categoryMapper::toDto)
                .orElseThrow(() -> new RuntimeException("Category not found: " + id));
    }

    @Transactional(readOnly = true)
    @Cacheable(value = "categories", key = "'slug_' + #slug")
    public CategoryDTO findBySlug(String slug) {
        return categoryRepo.findBySlugAndActiveTrue(slug).map(categoryMapper::toDto)
                .orElseThrow(() -> new RuntimeException("Category not found for slug: " + slug));
    }

    @Transactional(readOnly = true)
    @Cacheable(value = "categories", key = "'all_active'")
    public List<CategoryDTO> findAllActive() {
        return categoryRepo.findAllByActiveTrueOrderByNameAsc().stream().map(categoryMapper::toDto).toList();
    }

    @Transactional(readOnly = true)
    public List<CategoryDTO> findRootCategories() {
        return categoryRepo.findByParentIsNullAndActiveTrueOrderByNameAsc().stream().map(categoryMapper::toDto).toList();
    }

    @Transactional(readOnly = true)
    public List<CategoryDTO> findChildren(Integer parentId) {
        validateExists(parentId);
        return categoryRepo.findByParentIdAndActiveTrueOrderByNameAsc(parentId).stream().map(categoryMapper::toDto).toList();
    }

    @Transactional(readOnly = true)
    public List<CategoryDTO> search(String keyword) {
        return categoryRepo.searchByName(keyword).stream().map(categoryMapper::toDto).toList();
    }

    @CacheEvict(value = "categories", allEntries = true)
    public CategoryDTO update(Integer id, UpdateCategoryRequest req) {
        Category category = categoryRepo.findByIdAndActiveTrue(id)
                .orElseThrow(() -> new RuntimeException("Category not found: " + id));

        if (req.getName() != null) {
            if (categoryRepo.existsByNameAndIdNot(req.getName(), id))
                throw new RuntimeException("Category name '" + req.getName() + "' already exists");
            category.setName(req.getName().trim());
            category.setSlug(generateSlug(req.getName()));
        }
        if (req.getImageUrl() != null) category.setImageUrl(req.getImageUrl());
        if (req.getParentId() != null) {
            if (req.getParentId().equals(id))
                throw new RuntimeException("Category cannot be its own parent");
            category.setParent(categoryRepo.findByIdAndActiveTrue(req.getParentId())
                    .orElseThrow(() -> new RuntimeException("Parent category not found: " + req.getParentId())));
        }
        Category saved = categoryRepo.save(category);
        log.info("Category updated id={}", saved.getId());
        return categoryMapper.toDto(saved);
    }

    @CacheEvict(value = "categories", allEntries = true)
    public void deactivate(Integer id) {
        validateExists(id);
        if (categoryRepo.existsByParentId(id))
            throw new RuntimeException("Cannot deactivate category with active children. Deactivate child categories first.");
        categoryRepo.deactivateById(id);
        log.info("Category deactivated id={}", id);
    }

    private void validateExists(Integer id) {
        if (!categoryRepo.existsById(id))
            throw new RuntimeException("Category not found: " + id);
    }

    private String generateSlug(String name) {
        return name.trim().toLowerCase()
                .replaceAll("[^a-z0-9\\s-]", "")
                .replaceAll("\\s+", "-")
                .replaceAll("-+", "-")
                .replaceAll("^-|-$", "");
    }
}