package com.pbp.ecomm.product.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Map;

// dto/ProductDTO.java
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductDTO {

    private String id;
    private String name;
    private String description;
    private String sku;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal price;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal discountedPrice;     // null if no active discount

    private Double discountPercent;

    private CategorySummary category;
    private String imageUrls;
    private Map<String, Object> attributes; // color, size, brand, weight etc.

    private Integer stockQuantity;          // available = quantity - reserved
    private Boolean inStock;

    private Double averageRating;
    private Integer reviewCount;

    private Boolean active;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime createdAt;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime updatedAt;

    // ── Nested summaries (avoids N+1 by embedding what frontend needs) ──

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CategorySummary {
        private Integer id;
        private String name;
        private String slug;
    }
}
