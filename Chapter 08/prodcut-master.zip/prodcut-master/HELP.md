# 🛒 Prodcut — E-Commerce Product Service

> A secure, production-ready Spring Boot microservice for e-commerce product management.  
> Built with **Java 21 · Spring Boot 4.0.6 · Gradle 8.x · MySQL · JWT Authentication**

[![Java](https://img.shields.io/badge/Java-21-blue)](https://openjdk.org/projects/jdk/21/)
[![Spring Boot](https://img.shields.io/badge/Spring%20Boot-4.0.6-brightgreen)](https://spring.io/projects/spring-boot)
[![Gradle](https://img.shields.io/badge/Gradle-8.x-02303A)](https://gradle.org/)
[![MySQL](https://img.shields.io/badge/MySQL-8.3-orange)](https://www.mysql.com/)

---

## 📋 Table of Contents

- [Overview](#overview)
- [Tech Stack](#tech-stack)
- [Project Structure](#project-structure)
- [Prerequisites](#prerequisites)
- [Getting Started](#getting-started)
- [Configuration](#configuration)
- [Running the Application](#running-the-application)
- [Authentication](#authentication)
- [API Endpoints](#api-endpoints)
- [Testing](#testing)
- [Build & Package](#build--package)
- [Contributing](#contributing)

---

## Overview

`prodcut` is a Spring Boot REST microservice built for an e-commerce platform (`com.pbp.ecomm`). It provides:

- Secure **JWT-based** authentication and authorization via Spring Security
- Product catalogue management (CRUD operations)
- Bean validation on all incoming requests
- Clean DTO-to-entity mapping via **MapStruct**
- Boilerplate-free code with **Lombok**
- MySQL persistence via Spring Data JPA

---

## Tech Stack

| Layer | Technology |
|---|---|
| Language | Java 21 |
| Framework | Spring Boot 4.0.6 |
| Build Tool | Gradle 8.x |
| Database | MySQL 8.3 |
| ORM | Spring Data JPA (Hibernate) |
| Security | Spring Security + JWT (jjwt 0.11.5) |
| Mapping | MapStruct 1.5.5 |
| Boilerplate | Lombok |
| Validation | Spring Boot Starter Validation (JSR-380) |
| Testing | JUnit 5, Spring Security Test |

---

## Project Structure

```
prodcut/
├── src/
│   ├── main/
│   │   ├── java/com/pbp/ecomm/
│   │   │   ├── ProdcutApplication.java       ← Entry point
│   │   │   ├── config/                        ← Security & app configuration
│   │   │   ├── controller/                    ← REST controllers
│   │   │   ├── service/                       ← Business logic
│   │   │   ├── repository/                    ← Spring Data JPA repositories
│   │   │   ├── domain/
│   │   │   │   ├── entity/                   ← JPA entities
│   │   │   │   └── dto/                      ← Request / Response DTOs
│   │   │   ├── mapper/                        ← MapStruct mappers (DTO ↔ Entity)
│   │   │   ├── security/                      ← JWT filter, token provider, UserDetails
│   │   │   └── exception/                     ← Custom exceptions + GlobalExceptionHandler
│   │   └── resources/
│   │       ├── application.yml
│   │       ├── application-dev.yml
│   │       └── application-prod.yml
│   └── test/
│       └── java/com/pbp/ecomm/
│           ├── controller/                    ← WebMvcTest controller tests
│           └── service/                       ← Unit tests with Mockito
├── gradle/wrapper/
├── build.gradle
├── settings.gradle
├── gradlew
└── gradlew.bat
```

---

## Prerequisites

| Tool | Version |
|---|---|
| Java (JDK) | 21+ |
| Gradle | 8.x (or use `./gradlew`) |
| MySQL | 8.3+ |
| Git | Any recent version |

---

## Getting Started

### 1. Clone the repository

```bash
git clone https://github.com/siddharthgelda/prodcut.git
cd prodcut
```

### 2. Create the MySQL database

```sql
CREATE DATABASE prodcut_db;
CREATE USER 'prodcut_user'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON prodcut_db.* TO 'prodcut_user'@'localhost';
FLUSH PRIVILEGES;
```

### 3. Configure the application

Update `src/main/resources/application.yml` with your database credentials and JWT secret:

```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/prodcut_db
    username: prodcut_user
    password: your_password
    driver-class-name: com.mysql.cj.jdbc.Driver
  jpa:
    hibernate:
      ddl-auto: update
    show-sql: true

app:
  jwt:
    secret: your_jwt_secret_key_here
    expiration-ms: 86400000   # 24 hours
```

### 4. Build the project

```bash
./gradlew clean build
```

---

## Configuration

### Key application.yml Properties

```yaml
server:
  port: 8080

spring:
  application:
    name: prodcut

  datasource:
    url: jdbc:mysql://localhost:3306/prodcut_db
    username: ${DB_USERNAME}
    password: ${DB_PASSWORD}

  jpa:
    hibernate:
      ddl-auto: validate      # use 'update' for dev, 'validate' for prod
    show-sql: false
    properties:
      hibernate:
        dialect: org.hibernate.dialect.MySQLDialect

app:
  jwt:
    secret: ${JWT_SECRET}
    expiration-ms: 86400000
```

### Environment Variables (Recommended for Production)

| Variable | Description |
|---|---|
| `DB_USERNAME` | MySQL database username |
| `DB_PASSWORD` | MySQL database password |
| `JWT_SECRET` | Secret key for signing JWT tokens |

---

## Running the Application

### Using Gradle

```bash
# Default run
./gradlew bootRun

# Run with a specific profile
./gradlew bootRun --args='--spring.profiles.active=dev'
```

### Using JAR

```bash
# Build the JAR first
./gradlew bootJar

# Run it
java -jar build/libs/prodcut-0.0.1-SNAPSHOT.jar --spring.profiles.active=dev
```

### Using Docker (optional)

Create a `Dockerfile`:

```dockerfile
FROM eclipse-temurin:21-jre
COPY build/libs/prodcut-0.0.1-SNAPSHOT.jar app.jar
ENTRYPOINT ["java", "-jar", "/app.jar"]
```

Then build and run:

```bash
docker build -t prodcut:latest .
docker run -p 8080:8080 \
  -e DB_USERNAME=prodcut_user \
  -e DB_PASSWORD=your_password \
  -e JWT_SECRET=your_secret \
  prodcut:latest
```

---

## Authentication

This service uses **JWT (JSON Web Token)** stateless authentication via Spring Security.

### Auth Flow

```
POST /api/auth/register   →  Create a new user account
POST /api/auth/login      →  Returns a signed JWT token
Authorization: Bearer <token>  →  Include in header for all protected requests
```

### Register

```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username": "user@example.com", "password": "password123"}'
```

### Login

```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "user@example.com", "password": "password123"}'
```

**Response:**

```json
{
  "token": "eyJhbGciOiJIUzI1NiJ9...",
  "type": "Bearer",
  "expiresIn": 86400000
}
```

### Using the Token

```bash
curl http://localhost:8080/api/v1/products \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiJ9..."
```

---

## API Endpoints

Base URL: `http://localhost:8080/api/v1`

### Auth Endpoints

| Method | Path | Description | Auth Required |
|---|---|---|---|
| `POST` | `/auth/register` | Register a new user | No |
| `POST` | `/auth/login` | Login and receive JWT | No |

### Product Endpoints

| Method | Path | Description | Auth Required |
|---|---|---|---|
| `GET` | `/products` | List all products (paginated) | Yes |
| `GET` | `/products/{id}` | Get product by ID | Yes |
| `POST` | `/products` | Create a new product | Yes |
| `PUT` | `/products/{id}` | Update product details | Yes |
| `DELETE` | `/products/{id}` | Delete a product | Yes |

---

## Testing

### Run all tests

```bash
./gradlew test
```

### Run a specific test class

```bash
./gradlew test --tests "com.pbp.ecomm.service.ProductServiceTest"
```

### View test report

```bash
open build/reports/tests/test/index.html
```

### Test coverage

| Type | Layer | Tools |
|---|---|---|
| Unit Tests | Service | JUnit 5, Mockito |
| Controller Tests | Controller | WebMvcTest, MockMvc |
| Security Tests | Auth / Filters | Spring Security Test |

---

## Build & Package

| Command | Description |
|---|---|
| `./gradlew clean build` | Full clean build including tests |
| `./gradlew clean build -x test` | Build skipping tests |
| `./gradlew bootRun` | Run the application locally |
| `./gradlew bootJar` | Package as executable JAR |
| `./gradlew test` | Run all tests |
| `./gradlew dependencies` | View full dependency tree |

---

## Key Dependencies

| Dependency | Version | Purpose |
|---|---|---|
| `spring-boot-starter-webmvc` | 4.0.6 | REST API (Jackson, Tomcat) |
| `spring-boot-starter-data-jpa` | 4.0.6 | ORM / Repository layer |
| `spring-boot-starter-security` | 4.0.6 | Authentication & Authorization |
| `spring-boot-starter-validation` | 4.0.6 | Request validation (JSR-380) |
| `mysql-connector-j` | 8.3.0 | MySQL JDBC driver |
| `mapstruct` | 1.5.5.Final | Compile-time DTO ↔ Entity mapping |
| `lombok` | (managed) | Boilerplate reduction |
| `jjwt-api` | 0.11.5 | JWT token creation & parsing |
| `jjwt-impl` | 0.11.5 | JWT implementation (runtime) |
| `jjwt-jackson` | 0.11.5 | JWT JSON serialization (runtime) |

---

## Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/your-feature-name`
3. Follow the existing package structure under `com.pbp.ecomm`
4. Write unit tests for all new service methods
5. Ensure `./gradlew clean build` passes before raising a PR
6. Open a Pull Request with a clear description of changes

---

## Repository Info

| Property | Value |
|---|---|
| GitHub | https://github.com/siddharthgelda/prodcut |
| Group | `com.pbp.ecomm` |
| Artifact | `prodcut` |
| Version | `0.0.1` |
| Branch | `master` |

---

*Built with Java 21 · Spring Boot 4.0.6 · Gradle · MySQL · JWT*
